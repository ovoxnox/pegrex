---
name: pegrex-specs
description: Mine, check, and compile specifications: Daikon-style mining, NL claims, and the anti-hallucination compiler. Use when intent must become proven code.
---

# spec discipline

- `specmine.mine(path)` classifies candidates proven / likely / dropped
  -- never asserts. `nlspec.check(path, nl_text="...")` proves, drops,
  or refuses NL claims.
- `antihalluc.compile_nl(text, src)`: NL -> spec -> IR -> code -> proof.
  A false sentence ships NOTHING (code: None). The compiler cannot
  hallucinate because it cannot ship what it cannot prove.
